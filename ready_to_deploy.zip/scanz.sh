source_code/scanz_libraries/bin/python3 source_code/scanz.py
